using Microsoft.VisualStudio.TestTools.UnitTesting;
using LPISCurrenyConverterAPI;
using LPISCurrenyConverterAPI.Controllers;

namespace LP_Technical_Test_Unit_Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public async System.Threading.Tasks.Task TestGetAsync()
        {
            var currencyContoller = new CurrencyController();
          // var res = await currencyContoller.Get();


        }
    }
}
