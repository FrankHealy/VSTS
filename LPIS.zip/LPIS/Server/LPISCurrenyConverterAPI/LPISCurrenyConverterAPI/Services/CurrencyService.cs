﻿using LPISCurrenyConverterAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LPISCurrenyConverterAPI.Services
{
    public class CurrencyService
    {
        public IQueryable<CurrencyModel> GetCurrencyList()
        {
            var currencylist = new List<CurrencyModel>();

            currencylist.Add(new CurrencyModel { CurrencyCode = "USD", CurrencyName ="US Dollar", ExchangeRate = 1.2322 });
            currencylist.Add(new CurrencyModel { CurrencyCode = "GBP",  CurrencyName = "GB Pound", ExchangeRate = .93433 });
            currencylist.Add(new CurrencyModel { CurrencyCode = "CHF", CurrencyName="Swiss Franc",ExchangeRate = 5.23433 });
            currencylist.Add(new CurrencyModel { CurrencyCode = "JPY", CurrencyName = "Japanese Yen", ExchangeRate = 12.3234 });
            currencylist.Add(new CurrencyModel { CurrencyCode = "SFR", CurrencyName = "Sounth African Rans", ExchangeRate = 15.23433 });
            currencylist.Add(new CurrencyModel { CurrencyCode = "AUD", CurrencyName = "Australian Dollar", ExchangeRate = 1.23433 });
            currencylist.Add(new CurrencyModel { CurrencyCode = "CAN", CurrencyName = "Canadian Dollar", ExchangeRate = 1.3343 });

            return currencylist.AsQueryable();

        }

    }
}
