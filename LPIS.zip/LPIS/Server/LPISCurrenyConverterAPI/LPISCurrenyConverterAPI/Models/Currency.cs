﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LPISCurrenyConverterAPI.Models
{
    public class CurrencyModel
    {
        public string CurrencyCode { get; set; }

        public string CurrencyName { get; set; }

        public double ExchangeRate { get; set; }

        public string CurrencyFlagURL { get; set; }

        public string  CurrencySymbolURL{ get; set; }
    }
}
