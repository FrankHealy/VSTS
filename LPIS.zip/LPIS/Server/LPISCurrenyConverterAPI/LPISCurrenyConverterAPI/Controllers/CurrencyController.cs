﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http.Cors;
using LPISCurrenyConverterAPI.Services;
using Microsoft.AspNetCore.Mvc;
using System.Runtime.Serialization.Json;



namespace LPISCurrenyConverterAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CurrencyController : Controller
    {

        [Route("/currency/getAllCurrencies")]
        [HttpGet]
        async public Task<IActionResult> Get()
        {
            var currencyService = new CurrencyService();

            return Json(currencyService.GetCurrencyList());
        }

        [HttpGet]
        [Route("/currency/filterStartsWith/{startsWith}")]
         public IActionResult FilterStartsWith(string startsWith)
        { 
        
            var currencyServicec = new CurrencyService();

            var res = currencyServicec.GetCurrencyList();

            var result = Json(res.Where(s => s.CurrencyName.ToUpper().Substring(0, startsWith.Length ) == startsWith.ToUpper()));


            return result;
        }

        [HttpGet]
        [Route("/currency/filterContains/{containsText}")]
        public IActionResult FilterContains(string containsText)
        {
            var currencyService = new CurrencyService();

            var res = currencyService.GetCurrencyList();

            var result = Json(res.Where(s => s.CurrencyName.ToUpper().Contains(containsText.ToUpper())));

            return result;


        }



    }
}
