import React, {Fragment}  from 'react';
import image from '../images/logo.svg'
import SelectCurrency from "../components/SelectCurrency"
import {Typeahead} from 'react-bootstrap-typeahead'; 

class App extends React.Component {

  constructor(props){
    super(props);
    this.state = {
      currencies: [],
      exchangeRate:0,
      calculateDisabled:true,
      amount:0,
      total:0,
      isLoading:false 
    }

    this.onSelectCurrency = this.onSelectCurrency.bind(this);
    this.runCalculation = this.runCalculation.bind(this);
    this.handleTotalChange = this.handleTotalChange.bind(this);

  }

 onSelectCurrency(currencyCode){
   const {currencies} =this.state;
   const currency = currencies.filter(currency=>currency.currencyCode===currencyCode);
   this.setState({currencyChosen:currency})
   this.setState({exchangeRate: currency[0].exchangeRate});
   this.setState({total:0})
   this.setState({amount:0});
   this.setState({calculateDisabled:true});
   
  //console.log("Currency Selected " + currencyCode + " ExchangeRate "+ currency[0].exchangeRate)
 }

  componentDidMount() {
    fetch('http://localhost:50183/currency/getAllCurrencies')
   .then(res => res.json())
   .then(json => {

    this.setState({currencies: json});
    this.setState({exchangeRate: this.state.currencies[0].exchangeRate});
    
   })}
  
   runCalculation(){

      const {exchangeRate,amount} = this.state;
      

      var conversion = exchangeRate*amount;
      this.setState({total:conversion});
    
    }

  
    handleTotalChange(e){

      this.setState({amount: e.target.value});
      if (e.target.value > 0)
        this.setState({calculateDisabled:false});
      else
      this.setState({calculateDisabled:true});
      
        if (e.target.value === "")
        this.setState({calculateDisabled:true});

        //Ensure integer only
        if(e.target.value % 1 != 0)
          this.setState({calculateDisabled:true});

    }    
  render(){

    const {currencies,exchangeRate} = this.state;
    const {} = this.state;
    return (
      <div>
        <header>
          <img src={image} />
          <div className="topText">
          Currency Exchange Calculator
          </div>
        </header>
        <div className="content">
          <div className="row">
            <div className="col-sm-12">
              <span className="input-spacing">
                Select Currency  :
              </span>

              
              <Fragment>
        <Typeahead
          labelKey="currencyName"
          
          options={this.state.currencies}
          placeholder="Choose a currency..."
          onChange={(selected) => {
            this.setState({total:0})
            this.setState({amount:0});
            this.setState({calculateDisabled:true});
            console.log("Selected");
          }}
        />
       
        
      </Fragment>

            </div>
          </div>
          <div className="row">
            <div className="col-sm-12">
              
              <p>
                Exchange Rate: {exchangeRate}
              </p>
            </div>
          </div>
          <div className="row">
            <div className="col-sm-6">
              
              <div className="input-group">
                <span className="input-group-addon input-spacing">Amount :  </span>
                <input type="number" defaultValue={0} className="form-control resizeHeight" aria-describedby="basic-addon2" step="1" pattern="\d\.\d{2}" value = {this.state.amount} onChange={this.handleTotalChange} />
                
              </div>

            </div>

            <div className="row">
            <div className="col-sm-12">
            <button className="resizeHeight" disabled={this.state.calculateDisabled} onClick={this.runCalculation}>Calculate</button>
            </div>
          </div>
            
          </div>
          <div className="row">
            <div className="col-sm-12">
           <p>  
                <span>Result  :</span> {this.state.total}
              </p>
            </div>
          </div>
        
        </div>
      </div>
    )
  }
}

export default App;